import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const router = Router();

router.post('/start', async (req, res) => {
  const { userId, botName, discordToken, botCode } = req.body;
  const bot = await prisma.bot.create({
    data: { name: botName, userId, state: 'live' }
  });
  res.json({ success: true, bot });
});

router.post('/stop', async (req, res) => {
  const { botId } = req.body;
  await prisma.bot.update({ where: { id: botId }, data: { state: 'stopped' } });
  res.json({ success: true });
});

router.get('/status/:botId', async (req, res) => {
  const bot = await prisma.bot.findUnique({ where: { id: Number(req.params.botId) } });
  if (!bot) return res.status(404).send('Bot not found');
  res.json({ state: bot.state });
});

export default router;
