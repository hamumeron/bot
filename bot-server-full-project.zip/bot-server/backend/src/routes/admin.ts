import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const router = Router();

router.get('/summary', async (_req, res) => {
  const bots = await prisma.bot.findMany();
  const live = bots.filter(bot => bot.state === 'live').length;
  res.json({ total: bots.length, live });
});

router.get('/all', async (_req, res) => {
  const bots = await prisma.bot.findMany({ include: { user: true } });
  res.json(bots);
});

export default router;
