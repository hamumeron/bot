import React, { useEffect, useState } from 'react';

export default function AdminDashboard() {
  const [summary, setSummary] = useState<any>(null);
  const [bots, setBots] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/admin/summary').then(r => r.json()).then(setSummary);
    fetch('/api/admin/all').then(r => r.json()).then(setBots);
  }, []);

  return (
    <div>
      <h1>管理ダッシュボード</h1>
      <p>稼働中Bot: {summary?.live} / {summary?.total}</p>
      <ul>
        {bots.map(bot => (
          <li key={bot.id}>{bot.name} - 状態: {bot.state}</li>
        ))}
      </ul>
    </div>
  );
}
