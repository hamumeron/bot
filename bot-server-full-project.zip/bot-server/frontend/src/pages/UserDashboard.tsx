import React, { useState } from 'react';

export default function UserDashboard() {
  const [botName, setBotName] = useState('');
  const [discordToken, setDiscordToken] = useState('');
  const [botId, setBotId] = useState<number | null>(null);
  const [status, setStatus] = useState<string | null>(null);

  const start = async () => {
    const res = await fetch('/api/user/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: 1, botName, discordToken, botCode: 'console.log("Bot running")' })
    });
    const data = await res.json();
    setBotId(data.bot.id);
  };

  const stop = async () => {
    if (!botId) return;
    await fetch('/api/user/stop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ botId })
    });
  };

  const checkStatus = async () => {
    if (!botId) return;
    const res = await fetch(`/api/user/status/${botId}`);
    const data = await res.json();
    setStatus(data.state);
  };

  return (
    <div>
      <h1>ユーザーダッシュボード</h1>
      <input placeholder="Bot名" value={botName} onChange={e => setBotName(e.target.value)} /><br />
      <input placeholder="Discord Token" value={discordToken} onChange={e => setDiscordToken(e.target.value)} /><br />
      <button onClick={start}>起動</button>
      <button onClick={stop}>停止</button>
      <button onClick={checkStatus}>状態確認</button>
      <div>{status && `状態: ${status}`}</div>
    </div>
  );
}
